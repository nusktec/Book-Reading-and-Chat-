// Initialize Firebase
  var config = {
    apiKey: "AIzaSyDjIw-gbo7XPuh8QFXDOS9tOABuTP7wOnY",
    authDomain: "seedsapp-642ad.firebaseapp.com",
    databaseURL: "https://seedsapp-642ad.firebaseio.com",
    projectId: "seedsapp-642ad",
    storageBucket: "seedsapp-642ad.appspot.com",
    messagingSenderId: "685668270303"
  };
  firebase.initializeApp(config);